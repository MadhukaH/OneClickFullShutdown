# 🔴 Full Shutdown Tool - ASUS ROG G16

## 🚀 One-Click Full Shutdown

Double-click **FullShutdown.exe** to perform a **true full shutdown** that bypasses Windows Fast Startup.

---

## ⚡ Quick Start

1. **Double-click** `FullShutdown.exe`
2. A confirmation dialog will appear
3. Click **"Yes"** to shutdown immediately
4. Click **"No"** to cancel

**That's it!** No window, no UI - just one click and a confirmation.

---

## 🎮 Why Use This?

Windows "Shut down" is **not a real shutdown** when Fast Startup is enabled. This can cause:

- ✗ Fans still spinning after shutdown
- ✗ RGB / keyboard lights staying ON
- ✗ Driver & GPU issues
- ✗ Power not fully cutting off

**This tool fixes that** by forcing a complete shutdown.

---

## 🔐 Admin Privileges Required

Windows will ask for **Administrator permission** (UAC prompt) - **Click Yes**.

This is required to perform the full shutdown command.

---

## 💡 Pro Tips

### 📌 Pin to Taskbar (Recommended)
1. Right-click `FullShutdown.exe`
2. Select **"Pin to taskbar"**
3. Now you have instant one-click shutdown from your taskbar!

### 🖥️ Create Desktop Shortcut
1. Right-click `FullShutdown.exe`
2. Select **"Send to"** → **"Desktop (create shortcut)"**

### 🔓 Skip UAC Prompt (Advanced)
1. Right-click `FullShutdown.exe`
2. Select **"Properties"**
3. Go to **"Compatibility"** tab
4. Check **"Run this program as an administrator"**
5. Click **OK**

Now it will always run as admin without asking!

---

## 🎯 Command Used

```cmd
shutdown /s /f /t 0
```

- `/s` = **Shutdown** the computer
- `/f` = **Force** close all applications
- `/t 0` = **Immediate** (0 seconds delay)

This bypasses Fast Startup for a complete shutdown.

---

## ⚙️ Requirements

- **Windows 10/11**
- **.NET 6.0 Runtime** (usually already installed)
- **Administrator privileges**

---

## ❓ Troubleshooting

**Problem:** "Access Denied" error  
**Solution:** Right-click the file → **"Run as administrator"**

**Problem:** Missing .NET Runtime  
**Solution:** Download from https://dotnet.microsoft.com/download/dotnet/6.0

---

**Perfect for ASUS ROG G16 gaming laptops!** 🎮

Stops fans, turns off LEDs, and ensures a complete power-off.
